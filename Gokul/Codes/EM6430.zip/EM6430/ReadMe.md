COMMAND                Discription
------------------------------------------------------
A 					Current average

A1 					Current, phase 1

A2 					Current, phase 2

A3 					Current, phase 3

VLL 				Line to line average voltage

VLN 				Line to neutral voltage

V12 				Voltage phase 1 to phase 2

V23 				Voltage phase 2 to phase

V31 				Voltage phase 3 to phase

V1 					Voltage phase 1 to neutral

V2 					Voltage phase 2 to neutral

V3 					Voltage phase 3 to neutral

W 					Active power, total

W1 					Active power, phase 1

W2				    Active power, phase 2

W3 					Active power, phase 3

VAR  				Reactive power, total

VAR1 				Reactive power, phase 1 

VAR2 				Reactive power, phase 2 

VAR3  				Reactive power, phase 3 

VA  				Apparent power, total 

VA1  				Apparent power, phase 1 

VA2  				Apparent power, phase 2 

VA3  				Apparent power, phase 3 

PF  				Power factor average 

PF1  				Power factor, phase 1 

PF2  				Power factor, phase 2 

PF3  				Power factor, phase 3 

Freq  				Frequency, Hz 

FwdVAh  			Forward apparent energy 

FwdWh  				Forward active energy 
----------------------------------------------------------------------------------------------

                                    Function's How they Works
----------------------------------------------------------------------------------------------

1)      EM6430.begin(baud_rate);  To set the baud_rate according to the baud_rate in meter.

2)      EM6430.EM6430_Command(Command,Device ID);  give the commands listed above ,and give Device id 1-254 set according to the Meter.

3)      EM6430.EM6430_Data(); Call the fuction it will return the float data from device.





































