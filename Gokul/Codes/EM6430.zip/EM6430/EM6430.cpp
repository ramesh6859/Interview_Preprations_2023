#include<avr/pgmspace.h>
#include<stdio.h>
#include<stdlib.h>
#include"traffic.h"
#include"EM6430.h"
#include "Arduino.h"
#include<avr/pgmspace.h>

uint8_t * EM6430 :: BUFFER[2]={NULL};

EM6430 :: EM6430()
{}

void EM6430 :: begin(uint32_t baud_rate)
{
	Serial.begin(baud_rate,EM6430_Data_Pack_Config);
}


void EM6430::EM6430_Command(uint8_t command,uint8_t dev_id)
{
uint8_t j;
BUFFER[0]=(uint8_t *)malloc(command_buff_size*sizeof(uint8_t));	
for(int i=0;i<command_buff_size;i++)
	{
	BUFFER[0][i]=0x00;
	}
			for(j=1;j<9;j++)
			{
				BUFFER[0][j]=pgm_read_byte_near(COMMAND+command+j);
			}
            dev_id >>4 & 0x0F;
			dev_id & 0x0F;
			Serial.write(dev_id);
		for (int i=1; i < 8; i++) Serial.write(BUFFER[0][ i ]);
		free(BUFFER[1]);
}

float EM6430::EM6430_Data()
{
	float x=0;
BUFFER[1]=(uint8_t *)malloc(data_buff_size*sizeof(uint8_t));	
for(int i=0;i<data_buff_size;i++)
	{
	BUFFER[1][i]=0x00;
	}
 while(Serial.available()<9);
 for (int i=0; i < 9; i++)BUFFER[1][i] = Serial.read();
 Serial.flush();
 ((byte*)&x)[8]= BUFFER[1][0];
 ((byte*)&x)[7]= BUFFER[1][1];
 ((byte*)&x)[6]= BUFFER[1][2];
 ((byte*)&x)[5]= BUFFER[1][3];
 ((byte*)&x)[4]= BUFFER[1][4];
 ((byte*)&x)[3]= BUFFER[1][5];
 ((byte*)&x)[2]= BUFFER[1][6];
 ((byte*)&x)[1]= BUFFER[1][7];
 ((byte*)&x)[0]= BUFFER[1][8];
 free(BUFFER[1]);
return x;
	
}