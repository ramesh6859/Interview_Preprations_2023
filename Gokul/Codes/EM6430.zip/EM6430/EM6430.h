#include "Arduino.h"
#include<avr/pgmspace.h>

#ifndef EM6430_h
#define EM6430_h
/* Current average */
#ifndef A
#define A 0
#endif
/* Current, phase 1 */
#ifndef A1 
#define A1 8
#endif
/* Current, phase 2 */
#ifndef A2 
#define A2 16
#endif
/* Current, phase 3 */
#ifndef A3 
#define A3 24
#endif
/* Line to line average voltage */
#ifndef VLL
#define VLL 32
#endif
/* Line to neutral voltage */
#ifndef VLN 
#define VLN 40
#endif
/* Voltage phase 1 to phase 2 */
#ifndef V12 
#define V12 48
#endif
/* Voltage phase 2 to phase */
#ifndef V23 
#define V23 56
#endif
/* Voltage phase 3 to phase */
#ifndef V31 
#define V31 64
#endif
/* Voltage phase 1 to neutral */
#ifndef V1 
#define V1 72
#endif
/* Voltage phase 2 to neutral */
#ifndef V2 
#define V2 80
#endif
/* Voltage phase 3 to neutral */
#ifndef V3 
#define V3 88
#endif
/* Active power, total */
#ifndef  W
#define  W 96
#endif
/* Active power, phase 1 */
#ifndef W1 
#define W1 104
#endif
/* Active power, phase 2 */
#ifndef W2 
#define W2 112
#endif
/* Active power, phase 3 */
#ifndef W3
#define W3 120
#endif
/* Reactive power, total */
#ifndef VAR 
#define VAR 128
#endif
/* Reactive power, phase 1 */
#ifndef VAR1
#define VAR1 136
#endif
/* Reactive power, phase 2 */
#ifndef VAR2 
#define VAR2 144
#endif
/* Reactive power, phase 3 */
#ifndef VAR3
#define VAR3 152
#endif
/* Apparent power, total */
#ifndef VA 
#define VA 160
#endif
/* Apparent power, phase 1 */
#ifndef VA1 
#define VA2 168
#endif
/* Apparent power, phase 2 */
#ifndef VA2 
#define VA2 176
#endif
/* Apparent power, phase 3 */
#ifndef VA3 
#define VA3 184
#endif
/* Power factor average */
#ifndef PF 
#define PF 192
#endif
/* Power factor, phase 1 */
#ifndef PF1 
#define PF1 200
#endif
/* Power factor, phase 2 */
#ifndef PF2 
#define PF2 208
#endif
/* Power factor, phase 3 */
#ifndef PF3
#define PF3 216
#endif
/* Frequency, Hz */
#ifndef Freq 
#define Freq 224
#endif
/* Forward apparent energy */
#ifndef FwdVAh 
#define FwdVAh 232
#endif
/* Forward active energy */
#ifndef FwdWh 
#define FwdWh 240
#endif

#define EM6430_Data_Pack_Config SERIAL_8E1
#define command_buff_size 7
#define data_buff_size 8

#endif
class EM6430
{
  public:
    EM6430();
	void begin(uint32_t baud_rate);
	void EM6430_Command(uint8_t command,uint8_t dev_id);
	float EM6430_Data(void);
	
 private:
	static uint8_t *BUFFER[2];
	static int Command_Buffer[command_buff_size];
	static int Data_Buffer[data_buff_size];
};